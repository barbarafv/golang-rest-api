package repository

import (
	entities "aplicacao/source/domain/entity"
	"log"

	_ "github.com/go-sql-driver/mysql"
	"github.com/jinzhu/gorm"
)

var DB *gorm.DB

func init() {
	var err error
	DB, err = gorm.Open("mysql", BuildDBConfig())

	if err != nil {
		log.Panic("An error ocurred during try to connect a database ", err)
	}

	DB.AutoMigrate(&entities.Planet{})
}

func BuildDBConfig() string {
	connectionString := "root:MyApplication92@tcp(127.0.0.1:3306)/dbtest?charset=utf8&parseTime=True&loc=Local"
	return connectionString
}
